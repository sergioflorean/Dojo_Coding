var miResultado = 0;

function miSuma(sumando) {  // 10
    miResultado = sumando + 1
    console.log(miResultado)
    return (miResultado + 1)
}

console.log(miResultado);
miResultado = miSuma(10)
console.log(miResultado)

//unaVariable = elReturndeLaFuncion(elParametro)

/*seleccionar el elemnto HTML */

var mihtmlSaludo = document.querySelector("#saludo");

console.log(mihtmlSaludo);
console.log("mihtmlSaludo");
console.log('mihtmlSaludo');

/* mihtmlSaludo.innerText = "hi i'm Susy!"
 */
/* mihtmlSaludo.style.color = 'pink';
 */
/*eliminaredad*/

var mihtmlEdad = document.querySelector("#edad");

/* mihtmlEdad.style.display = 'none';
 */
/* mihtmlEdad.remove();
 */
/* mihtmlEdad.style.visibility = 'hidden';
 */
/* 1.-escoger imagen */

var mihtmlImagen = document.querySelector('#centrado img')
console.log(mihtmlImagen);

/*2.-cambiar imagen*/

/* mihtmlImagen.src = "./imagenes/lucy.png";
 */
/*3.-agregar manejador de evento para cambiar imagen de manera dinamica */

mihtmlImagen.addEventListener('mouseover', cambiarImagen)

/*4.- definir que ocurre al hacer hover */

function cambiarImagen() {

    mihtmlImagen.src = "./imagenes/lucy.png";
    mihtmlEdad.style.visibility = 'hidden';
    mihtmlSaludo.style.color = 'pink';
    mihtmlSaludo.innerText = "hi i'm Susy!"
  
}






