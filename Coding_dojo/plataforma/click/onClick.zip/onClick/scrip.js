function turnOff(element) {
    element.innerText = "logout!";
}

function hide(element) {
    element.remove();
}

function myFunction() {
    alert("ninja was liked");
  }