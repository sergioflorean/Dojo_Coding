alturaNiño = 65
function muestraSiElNiñoPuedeSubirALaMontañaRusa (){

    if (alturaNiño > 52) {

        console.log("subete chico");
    
    }
    else {
        console.log("los siento chico, tal vez el próximo año");
    }
}
