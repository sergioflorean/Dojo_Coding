import axios from "axios";
import { useParams } from 'react-router-dom';

//  export const getApi = () => axios.get(`https://swapi.dev/api/people`)


// export const getApiInfo = () => axios.get(`https://swapi.dev/api/:selected/:chooseId`)