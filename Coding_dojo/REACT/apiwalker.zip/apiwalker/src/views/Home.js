import React from "react";
import ListApi from "../components/ListApi";
import ChoosingForm from "../components/ChoosingForm";

const Home = () => {

    return(
        <div>
            
            <ChoosingForm/>
            
        </div>
    );

}

export default Home;